﻿/// <reference path="lib/typings/definitelytyped/angularjs/angular.d.ts" />
/// <reference path="lib/typings/definitelytyped/cordova/cordova.d.ts" />
/// <reference path="lib/typings/definitelytyped/cordova-ionic/cordova-ionic.d.ts" />
/// <reference path="lib/typings/definitelytyped/angular-ui-router/angular-ui-router.d.ts" />
/// <reference path="lib/typings/ionic-typescript-definitions/beta14/ionic.d.ts" />

