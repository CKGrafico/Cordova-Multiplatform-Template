﻿module Core {
    'use strict';

    angular.module('core', []);
}
