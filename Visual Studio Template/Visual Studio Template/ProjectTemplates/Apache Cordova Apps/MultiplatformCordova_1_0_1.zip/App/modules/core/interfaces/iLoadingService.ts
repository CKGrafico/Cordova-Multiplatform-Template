﻿module Core {
    'use strict';

    export interface ILoadingService {
        show(): void,
        hide(): void
    }
}
