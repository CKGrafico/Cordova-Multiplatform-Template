##Instructions

### FIRST OF ALL you need Cordova Tools
https://www.visualstudio.com/en-us/features/cordova-vs.aspx
![Cordova comment](http://i.imgur.com/rfPEDIq.png)
![Cordova Tools installation](http://i.imgur.com/Zg7t52q.png)

###Create new project
![Instruction2](http://i.imgur.com/04BYe79.png)

###Install npm packages
![Instruction3](http://i.imgur.com/gKst68A.png)

###Run initialize task
![Instruction4](http://i.imgur.com/EW5oK51.png)

###Enjoy
![Instruction](http://i.imgur.com/DAG1g0x.png)
