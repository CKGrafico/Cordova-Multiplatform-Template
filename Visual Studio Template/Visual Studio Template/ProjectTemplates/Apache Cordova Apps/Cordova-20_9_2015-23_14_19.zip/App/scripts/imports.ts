// External dependencies

// d.ts
/// <reference path="lib/typings/angularjs/angular.d.ts" />
/// <reference path="lib/typings/angular-ui-router/angular-ui-router.d.ts" />
/// <reference path="lib/typings/ionic/ionic.d.ts" />
/// <reference path="lib/typings/cordova/cordova.d.ts" />
/// <reference path="lib/typings/cordova-ionic/cordova-ionic.d.ts" />

