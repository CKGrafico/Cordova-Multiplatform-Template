// External dependencies
// d.ts
/// <reference path="lib/typings/definitelytyped/angularjs/angular.d.ts" />
/// <reference path="lib/typings/definitelytyped/angular-ui-router/angular-ui-router.d.ts" />
/// <reference path="lib/typings/ionic-typescript-definitions/beta14/ionic.d.ts" />
/// <reference path="lib/typings/definitelytyped/cordova/cordova.d.ts" />
/// <reference path="lib/typings/definitelytyped/cordova-ionic/cordova-ionic.d.ts" />
/// <reference path="imports.ts" />
var App;
(function (App) {
    'use strict';
    document.addEventListener("deviceready", onDeviceReady, false);
    angular.module('App', ['ionic'])
        .config(['$stateProvider', '$urlRouterProvider', '$ionicConfigProvider', statesConfiguration])
        .config(['$httpProvider', httpLoadingInterceptor])
        .run(['$rootScope', '$ionicLoading', httpLoadingInterceptorActions])
        .config(['$compileProvider', function ($compileProvider) {
            $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|file|mailto|ms-appx):/);
        }]);
    function onDeviceReady() {
        angular.bootstrap(document.querySelector('body'), ['App']);
    }
    App.onDeviceReady = onDeviceReady;
    // Configure routes
    function statesConfiguration($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
        // force native scroll
        var configProvider = $ionicConfigProvider;
        configProvider.scrolling.jsScrolling(false);
        $stateProvider
            .state('tabs', {
            url: "/tab",
            abstract: true,
            templateUrl: "templates/partials/tabs.html"
        })
            .state('tabs.left', {
            url: "/left",
            views: {
                'left-tab': {
                    templateUrl: "templates/pages/left.html"
                }
            }
        })
            .state('tabs.home', {
            url: "/home",
            views: {
                'home-tab': {
                    templateUrl: "templates/pages/home.html"
                }
            }
        })
            .state('tabs.scroll', {
            url: "/scroll",
            views: {
                'home-tab': {
                    templateUrl: "templates/pages/scroll.html"
                }
            }
        })
            .state('tabs.actions', {
            url: "/actions",
            views: {
                'actions-tab': {
                    controller: 'actionsController as vm',
                    templateUrl: "templates/pages/actions.html"
                }
            }
        })
            .state('tabs.buttons', {
            url: "/buttons",
            views: {
                'buttons-tab': {
                    templateUrl: "templates/pages/buttons.html"
                }
            }
        });
        $urlRouterProvider.otherwise("/tab/home");
    }
    // Configure interceptor
    function httpLoadingInterceptor($httpProvider) {
        $httpProvider.interceptors.push(['$rootScope', function ($rootScope) {
                return {
                    request: function (config) {
                        $rootScope.$broadcast('loading:show');
                        return config;
                    },
                    response: function (response) {
                        $rootScope.$broadcast('loading:hide');
                        return response;
                    }
                };
            }]);
    }
    // Configure interceptor actions
    function httpLoadingInterceptorActions($rootScope, $ionicLoading) {
        $rootScope.$on('loading:show', function () {
            $ionicLoading.show({ templateUrl: "templates/partials/loading.html" });
        });
        $rootScope.$on('loading:hide', function () {
            $ionicLoading.hide();
        });
    }
})(App || (App = {}));
// Platform specific overrides will be placed in the merges folder versions of this file 
/// <reference path="../imports.ts" />
var App;
(function (App) {
    'use strict';
    var ActionsController = (function () {
        function ActionsController($http) {
            this.$http = $http;
            this.property = 'Void';
            $http.jsonp('http://api.openbeerdatabase.com/v1/breweries.json?callback=JSON_CALLBACK').then(function (result) {
                console.log(result);
            });
        }
        ActionsController.prototype.exampleAction = function () {
            this.property = 'Random ' + Math.floor(Math.random() * 100 + 1);
        };
        ActionsController.$inject = [
            '$http'
        ];
        return ActionsController;
    })();
    App.ActionsController = ActionsController;
    angular.module('App').controller('actionsController', ActionsController);
})(App || (App = {}));
/// <reference path="../imports.ts" />
var App;
(function (App) {
    'use strict';
    var NavigationController = (function () {
        function NavigationController($ionicHistory, $ionicTabsDelegate) {
            var _this = this;
            this.$ionicHistory = $ionicHistory;
            this.$ionicTabsDelegate = $ionicTabsDelegate;
            document.addEventListener('backbutton', function (e) { return _this.checkBack(e); }, false);
        }
        NavigationController.prototype.goBack = function () {
            this.$ionicHistory.goBack();
        };
        NavigationController.prototype.checkBack = function (e) {
            var page = this.$ionicHistory.currentStateName();
            if (page === 'tabs.home') {
                var nav = navigator;
                if (nav.app && nav.app.exitApp) {
                    nav.app.exitApp();
                }
                else {
                    window.close();
                }
            }
            else {
                this.goBack();
            }
        };
        // On Windows phone
        NavigationController.prototype.onSwipeLeft = function () {
            this.$ionicTabsDelegate.select(this.$ionicTabsDelegate.selectedIndex() + 1);
        };
        NavigationController.prototype.onSwipeRight = function () {
            this.$ionicTabsDelegate.select(this.$ionicTabsDelegate.selectedIndex() - 1);
        };
        NavigationController.$inject = [
            '$ionicHistory',
            '$ionicTabsDelegate'
        ];
        return NavigationController;
    })();
    App.NavigationController = NavigationController;
    angular.module('App').controller('navigationController', NavigationController);
})(App || (App = {}));
//# sourceMappingURL=appbundle.js.map