﻿module Core {
    'use strict';

    angular.module(Constants.Paths.Core, []);
}
