##Instructions

### FIRST OF ALL you need Cordova Tools
https://www.visualstudio.com/en-us/features/cordova-vs.aspx
![Cordova comment](http://i.imgur.com/rfPEDIq.png)
![Cordova Tools installation](http://i.imgur.com/Zg7t52q.png)

###Install NodeJS Tools for Visual Studio
https://nodejstools.codeplex.com/
![Instruction1](http://i.imgur.com/j6cbceG.png)

###Create new project
![Instruction2](http://i.imgur.com/04BYe79.png)

###Install npm packages
![Instruction3](http://i.imgur.com/gKst68A.png)

###Build project
(This compile TypeScript files before inject task)

###Run initialize task
![Instruction4](http://i.imgur.com/EW5oK51.png)

### ~~Include 'lib' folders to the project // In future versions we will make this automatically~~

###Enjoy
![Instruction](http://i.imgur.com/DAG1g0x.png)
